'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '127.0.0.1';
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(path.join(DATA_DIR, 'repair.sqlite'));
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL DEFAULT '', pass_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('admin','frontdesk','technician')), vip_level TEXT NOT NULL DEFAULT '普通', approved INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), expires_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS models(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS plans(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS vip_levels(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, discount_tenths INTEGER NOT NULL CHECK(discount_tenths BETWEEN 10 AND 100), created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY, serial TEXT NOT NULL, serial_last6 TEXT NOT NULL, model TEXT NOT NULL, customer TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','returned','cancelled')), created_by INTEGER NOT NULL REFERENCES users(id), created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_orders_serial ON orders(serial);
CREATE INDEX IF NOT EXISTS idx_orders_last6 ON orders(serial_last6);
CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id), plan TEXT NOT NULL, charge_cents INTEGER NOT NULL CHECK(charge_cents>=0), wage_cents INTEGER NOT NULL CHECK(wage_cents>=0), technician_id INTEGER NOT NULL REFERENCES users(id), status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','completed','returned','cancelled')), completed_at TEXT, charge_snapshot_cents INTEGER, wage_snapshot_cents INTEGER, completed_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_items_technician ON items(technician_id,status);
CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY, item_id INTEGER NOT NULL REFERENCES items(id), kind TEXT NOT NULL CHECK(kind IN ('charge','wage','charge_reversal','wage_reversal')), amount_cents INTEGER NOT NULL, technician_id INTEGER REFERENCES users(id), created_at TEXT NOT NULL, UNIQUE(item_id,kind));
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, actor_id INTEGER REFERENCES users(id), entity TEXT NOT NULL, entity_id INTEGER, action TEXT NOT NULL, details TEXT NOT NULL, created_at TEXT NOT NULL);
`);
if (!db.prepare("PRAGMA table_info(users)").all().some(column => column.name === 'is_superadmin')) db.exec('ALTER TABLE users ADD COLUMN is_superadmin INTEGER NOT NULL DEFAULT 0');
if (!db.prepare("PRAGMA table_info(users)").all().some(column => column.name === 'display_name')) db.exec("ALTER TABLE users ADD COLUMN display_name TEXT NOT NULL DEFAULT ''");

const now = () => new Date().toISOString();
const localDay = () => { const parts=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date()).map(p=>[p.type,p.value])); return `${parts.year}-${parts.month}-${parts.day}`; };
const bad = (status, message) => { const e = new Error(message); e.status = status; throw e; };
const required = (value, label) => { const s = String(value ?? '').trim(); if (!s) bad(400, `${label}不能为空`); return s; };
const money = (value, label) => { const s = String(value ?? ''); if (!/^(0|[1-9]\d*)(\.\d{1,2})?$/.test(s)) bad(400, `${label}必须是非负金额，最多两位小数`); const [whole, fraction = ''] = s.split('.'); const cents = Number(whole) * 100 + Number(fraction.padEnd(2, '0')); if (!Number.isSafeInteger(cents)) bad(400, `${label}超出范围`); return cents; };
const hashPassword = password => { const salt = crypto.randomBytes(16).toString('hex'); return `${salt}:${crypto.scryptSync(password, salt, 64).toString('hex')}`; };
const checkPassword = (password, stored) => { const [salt, hash] = stored.split(':'); return !!salt && !!hash && crypto.timingSafeEqual(crypto.scryptSync(password, salt, 64), Buffer.from(hash, 'hex')); };
const audit = (actor, entity, id, action, details = {}) => db.prepare('INSERT INTO audit(actor_id,entity,entity_id,action,details,created_at) VALUES(?,?,?,?,?,?)').run(actor, entity, id, action, JSON.stringify(details), now());
function tx(fn) { db.exec('BEGIN IMMEDIATE'); try { const result = fn(); db.exec('COMMIT'); return result; } catch (e) { db.exec('ROLLBACK'); throw e; } }
function seed() {
  if (!db.prepare("SELECT id FROM users WHERE role='admin' LIMIT 1").get() && process.env.ADMIN_PASSWORD) {
    if (process.env.ADMIN_PASSWORD.length < 5) throw new Error('ADMIN_PASSWORD 至少需要 5 位');
    db.prepare("INSERT INTO users(username,pass_hash,role,vip_level,approved,created_at) VALUES(?,?,'admin','管理员',1,?)").run(process.env.ADMIN_USERNAME || 'admin', hashPassword(process.env.ADMIN_PASSWORD), now());
  }
  if (!db.prepare('SELECT id FROM users WHERE is_superadmin=1 LIMIT 1').get() && process.env.SUPERADMIN_PASSWORD) {
    if (process.env.SUPERADMIN_PASSWORD.length < 5) throw new Error('SUPERADMIN_PASSWORD 至少需要 5 位');
    db.prepare("INSERT INTO users(username,pass_hash,role,vip_level,approved,created_at,is_superadmin) VALUES(?,?,'admin','超级管理员',1,?,1)").run(process.env.SUPERADMIN_USERNAME || 'superadmin', hashPassword(process.env.SUPERADMIN_PASSWORD), now());
  }
  if (!db.prepare("SELECT id FROM users WHERE role='admin' LIMIT 1").get()) throw new Error('首次启动请设置至少 5 位的 ADMIN_PASSWORD 或 SUPERADMIN_PASSWORD');
}
seed();
db.prepare('INSERT OR IGNORE INTO vip_levels(name,discount_tenths,created_at) VALUES(?,100,?)').run('普通',now());
for (const row of db.prepare("SELECT DISTINCT vip_level FROM users WHERE role='technician' AND vip_level<>''").all()) db.prepare('INSERT OR IGNORE INTO vip_levels(name,discount_tenths,created_at) VALUES(?,100,?)').run(row.vip_level,now());

function vipLevel(name) {
  const level=db.prepare('SELECT * FROM vip_levels WHERE name=?').get(required(name,'VIP 等级'));
  if (!level) bad(400,'请选择已配置的 VIP 等级');
  return level;
}
function discountTenths(value) {
  const text=String(value ?? '').trim();
  if (!/^(?:[1-9](?:\.\d)?|10(?:\.0)?)$/.test(text)) bad(400,'折扣须为 1 至 10 折，最多一位小数');
  return Math.round(Number(text)*10);
}
const roleLabel = u => u?.is_superadmin ? '超级管理员' : ({admin:'普通管理员',frontdesk:'前台',technician:'师傅'}[u?.role] || '系统');
function operationMessage(row) {
  const d=(()=>{ try{return JSON.parse(row.details||'{}')}catch{return {}} })();
  const who=`${row.actor_display_name||row.actor_name||'系统'}（${roleLabel(row)}）`;
  const messages={login:'登录了系统',registered:'注册了师傅账号',created:'创建了账号或维修项目',profile_updated:'修改了自己的资料',updated:'修改了账号或等级设置',added:'添加了基础资料',reassigned:'重新指派了维修项目',price_changed:'修改了维修项目价格',completed:'完成了维修项目并结算工价',returned:'办理了退机',cancelled:'取消了订单',created_order:'创建了维修订单'};
  let action=messages[row.action]||'进行了系统操作';
  if(row.action==='created' && row.entity==='order') action='创建了维修订单';
  if(row.action==='created' && row.entity==='item') action='添加了维修项目';
  if(row.action==='created' && row.entity==='user') action=d.role==='technician'?'创建了师傅账号':'创建了管理员或前台账号';
  if(row.action==='updated' && row.entity==='user') action='审核或修改了账号';
  if(row.action==='updated' && row.entity==='vip_level') action='修改了等级名称';
  const extra=[];
  if(d.username) extra.push(`登录账号“${d.username}”`);
  if(d.display_name) extra.push(`显示名称“${d.display_name}”`);
  if(d.name && row.entity==='vip_level') extra.push(`等级“${d.name}”`);
  if(d.plan) extra.push(`方案“${d.plan}”`);
  if(d.wage_cents!==undefined) extra.push(`工价 ${Number(d.wage_cents/100).toFixed(2)} 元`);
  return `${who}${action}${extra.length?'（'+extra.join('，')+'）':''}`;
}

function actor(req) {
  const token = (req.headers.authorization || '').match(/^Bearer (.+)$/)?.[1];
  if (!token) bad(401, '请先登录');
  const user = db.prepare('SELECT u.id,u.username,u.display_name,u.role,u.vip_level,u.approved,u.active,u.is_superadmin FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?').get(crypto.createHash('sha256').update(token).digest('hex'), now());
  if (!user || !user.active || !user.approved) bad(401, '登录已失效或账号未审核');
  if (user.is_superadmin) user.role = 'superadmin';
  return user;
}
function allow(user, ...roles) { if (!roles.includes(user.role) && !(user.role === 'superadmin' && roles.includes('admin'))) bad(403, '无权操作'); }
function cleanUser(u) { return { id:u.id, username:u.username, display_name:u.display_name || u.username, role:u.is_superadmin?'superadmin':u.role, vip_level:u.vip_level, approved:!!u.approved, active:!!u.active }; }
function getOrder(id) {
  const order = db.prepare('SELECT * FROM orders WHERE id=?').get(id);
  if (!order) bad(404, '订单不存在');
  order.items = db.prepare('SELECT i.*,u.username AS technician_name,u.vip_level FROM items i JOIN users u ON u.id=i.technician_id WHERE i.order_id=? ORDER BY i.id').all(id);
  return order;
}
function visibleOrder(user, id) {
  const order = getOrder(id);
  if (user.role === 'technician') {
    order.items = order.items.filter(i => i.technician_id === user.id);
    if (!order.items.length) bad(403, '此订单未分配给你');
  }
  return order;
}
function technician(id) {
  const u = db.prepare("SELECT * FROM users WHERE id=? AND role='technician' AND approved=1 AND active=1").get(Number(id));
  if (!u) bad(400, '请选择已审核的师傅');
  return u;
}
function addItem(orderId, input, actorId) {
  const plan = required(input.plan, '维修方案');
  const t = technician(input.technician_id);
  const charge = money(input.charge, '客户收费');
  const wage = money(input.wage, '工价');
  const id = db.prepare('INSERT INTO items(order_id,plan,charge_cents,wage_cents,technician_id,created_at) VALUES(?,?,?,?,?,?)').run(orderId,plan,charge,wage,t.id,now()).lastInsertRowid;
  db.prepare('INSERT OR IGNORE INTO plans(name) VALUES(?)').run(plan);
  audit(actorId,'item',Number(id),'created',{order_id:orderId,plan,charge_cents:charge,wage_cents:wage,technician_id:t.id});
  return Number(id);
}
function json(res, status, data) { const body = JSON.stringify(data); res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}); res.end(body); }
async function body(req) {
  let raw = ''; for await (const chunk of req) { raw += chunk; if (raw.length > 65536) bad(413,'请求过大'); }
  if (!raw) return {}; try { return JSON.parse(raw); } catch { bad(400,'JSON 格式错误'); }
}
const publicDir = path.join(__dirname,'public');
function serveStatic(req,res,url) {
  const page = {'/':'index.html','/shouji':'index.html','/chaojishouji':'index.html','/shifu':'technician.html'}[url.pathname];
  const relative = page || (url.pathname.startsWith('/repair-assets/') ? url.pathname.slice('/repair-assets/'.length) : null);
  if (!relative) bad(404,'不存在');
  const file = path.resolve(publicDir, relative);
  if (!file.startsWith(publicDir + path.sep) && file !== path.join(publicDir,'index.html')) bad(404,'不存在');
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) bad(404,'不存在');
  const ext = path.extname(file);
  res.writeHead(200, {'Content-Type': {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'}[ext] || 'application/octet-stream'});
  fs.createReadStream(file).pipe(res);
}
async function api(req,res,url) {
  const route = url.pathname.replace(/^\/(api|repair-api)/,''), method = req.method;
  if (route === '/health' && method === 'GET') return json(res,200,{ok:true});
  if (route === '/register' && method === 'POST') {
    const b = await body(req), username = required(b.username,'用户名'), password = required(b.password,'密码');
    if (password.length < 5) bad(400,'密码至少 5 位');
    try { const id = db.prepare("INSERT INTO users(username,pass_hash,role,created_at) VALUES(?,?,'technician',?)").run(username,hashPassword(password),now()).lastInsertRowid; audit(Number(id),'user',Number(id),'registered'); return json(res,201,{message:'注册成功，等待管理员审核'}); } catch (e) { if (e.code?.startsWith('SQLITE_CONSTRAINT')) bad(409,'用户名已存在'); throw e; }
  }
  if (route === '/login' && method === 'POST') {
    const b = await body(req), u = db.prepare('SELECT * FROM users WHERE username=?').get(required(b.username,'用户名'));
    if (!u || !checkPassword(String(b.password || ''),u.pass_hash)) bad(401,'用户名或密码错误');
    if (!u.approved || !u.active) bad(403,'账号待审核或已停用');
    const token = crypto.randomBytes(32).toString('hex');
    db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)').run(crypto.createHash('sha256').update(token).digest('hex'),u.id,new Date(Date.now()+7*86400000).toISOString());
    audit(u.id,'user',u.id,'login'); return json(res,200,{token,user:cleanUser(u)});
  }
  const user = actor(req);
  if (route === '/me' && method === 'GET') return json(res,200,{user:cleanUser(user)});
  if (route === '/me' && method === 'PATCH') {
    allow(user,'admin');
    const b=await body(req), displayName=required(b.display_name,'显示名称'), username=required(b.username,'登录账号');
    if (displayName.length>32 || username.length>32 || /[\x00-\x1f\x7f]/.test(displayName+username)) bad(400,'名称或账号格式无效（最多 32 字）');
    const current=db.prepare('SELECT * FROM users WHERE id=?').get(user.id);
    if (username!==current.username && !checkPassword(String(b.current_password||''),current.pass_hash)) bad(403,'修改登录账号需要输入正确的当前密码');
    try {
      tx(()=>{ db.prepare('UPDATE users SET username=?,display_name=? WHERE id=?').run(username,displayName,user.id); audit(user.id,'user',user.id,'profile_updated',{old_username:current.username,username,old_display_name:current.display_name||current.username,display_name:displayName}); });
    } catch(e) { if(e.code?.includes('CONSTRAINT') || /UNIQUE constraint failed/.test(e.message)) bad(409,'登录账号已存在'); throw e; }
    return json(res,200,{user:cleanUser(db.prepare('SELECT * FROM users WHERE id=?').get(user.id))});
  }
  if (route === '/users' && method === 'GET') { allow(user,'admin','frontdesk'); const rows = db.prepare("SELECT id,username,display_name,role,vip_level,approved,active,is_superadmin,created_at FROM users ORDER BY id DESC").all().map(u=>({...u,display_name:u.display_name||u.username,role:u.is_superadmin?'superadmin':u.role})); return json(res,200,{users: user.role==='frontdesk' ? rows.filter(u=>u.role==='technician'&&u.approved&&u.active) : rows}); }
  if (route === '/users' && method === 'POST') { allow(user,'admin'); const b=await body(req), username=required(b.username,'用户名'), displayName=required(b.display_name||username,'显示名称'), password=required(b.password,'密码'); if(username.length>32||displayName.length>32||/[\x00-\x1f\x7f]/.test(username+displayName)) bad(400,'名称或账号格式无效（最多 32 字）'); if(password.length<5) bad(400,'密码至少 5 位'); if(!['frontdesk','technician','admin'].includes(b.role)) bad(400,'角色无效'); if(b.role==='admin'&&user.role!=='superadmin') bad(403,'只有超级管理员可以创建普通管理员'); const vip=b.role==='technician'?vipLevel(b.vip_level||'普通').name:'普通'; try { const id=db.prepare('INSERT INTO users(username,display_name,pass_hash,role,vip_level,approved,created_at) VALUES(?,?,?,?,?,1,?)').run(username,displayName,hashPassword(password),b.role,vip,now()).lastInsertRowid; audit(user.id,'user',Number(id),'created',{role:b.role,username,display_name:displayName,vip_level:vip}); return json(res,201,{id:Number(id)}); } catch(e){ if(e.code?.startsWith('SQLITE_CONSTRAINT')) bad(409,'用户名已存在'); throw e; } }
  let match=route.match(/^\/users\/(\d+)$/);
  if(match && method==='PATCH') { allow(user,'admin'); const b=await body(req), target=db.prepare('SELECT * FROM users WHERE id=?').get(Number(match[1])); if(!target) bad(404,'账号不存在'); if(target.is_superadmin) bad(403,'不能修改超级管理员账号'); if(target.role==='admin'&&user.role!=='superadmin') bad(403,'只有超级管理员可以修改普通管理员'); const vip=target.role==='technician'?vipLevel(b.vip_level ?? target.vip_level).name:target.vip_level, approved=b.approved===undefined?target.approved:Number(!!b.approved), active=b.active===undefined?target.active:Number(!!b.active); db.prepare('UPDATE users SET vip_level=?,approved=?,active=? WHERE id=?').run(vip,approved,active,target.id); if(!active||!approved) db.prepare('DELETE FROM sessions WHERE user_id=?').run(target.id); audit(user.id,'user',target.id,'updated',{vip_level:vip,approved,active}); return json(res,200,{user:cleanUser(db.prepare('SELECT * FROM users WHERE id=?').get(target.id))}); }
  if (route === '/vip-levels' && method === 'GET') { allow(user,'admin','frontdesk'); return json(res,200,{levels:db.prepare('SELECT id,name,discount_tenths FROM vip_levels ORDER BY discount_tenths DESC,id').all()}); }
  if (route === '/vip-levels' && method === 'POST') { allow(user,'admin'); const b=await body(req), name=required(b.name,'等级名称'), discount=100; if(name.length>32||/[\x00-\x1f\x7f]/.test(name)) bad(400,'等级名称最多 32 字且不能包含控制字符'); try { const id=db.prepare('INSERT INTO vip_levels(name,discount_tenths,created_at) VALUES(?,?,?)').run(name,discount,now()).lastInsertRowid; audit(user.id,'vip_level',Number(id),'created',{name}); return json(res,201,{id:Number(id)}); } catch(e){ if(e.code?.includes('CONSTRAINT')||/UNIQUE constraint failed/.test(e.message)) bad(409,'等级名称已存在'); throw e; } }
  match=route.match(/^\/vip-levels\/(\d+)$/);
  if (match && method === 'PATCH') { allow(user,'admin'); const before=db.prepare('SELECT * FROM vip_levels WHERE id=?').get(Number(match[1])); if(!before) bad(404,'VIP 等级不存在'); const b=await body(req), name=required(b.name ?? before.name,'等级名称'), discount=before.discount_tenths; if(name.length>32||/[\x00-\x1f\x7f]/.test(name)) bad(400,'等级名称最多 32 字且不能包含控制字符'); try { tx(()=>{ db.prepare('UPDATE vip_levels SET name=?,discount_tenths=? WHERE id=?').run(name,discount,before.id); if(name!==before.name) db.prepare("UPDATE users SET vip_level=? WHERE role='technician' AND vip_level=?").run(name,before.name); audit(user.id,'vip_level',before.id,'updated',{old_name:before.name,name}); }); return json(res,200,{level:{id:before.id,name,discount_tenths:discount}}); } catch(e){ if(e.code?.includes('CONSTRAINT')||/UNIQUE constraint failed/.test(e.message)) bad(409,'等级名称已存在'); throw e; } }
  if (route === '/catalog' && method === 'GET') return json(res,200,{models:db.prepare('SELECT * FROM models ORDER BY name').all(),plans:db.prepare('SELECT * FROM plans ORDER BY name').all()});
  if (route === '/catalog' && method === 'POST') { allow(user,'admin'); const b=await body(req), table=b.kind==='model'?'models':b.kind==='plan'?'plans':null; if(!table) bad(400,'类型无效'); const name=required(b.name,'名称'); db.prepare(`INSERT OR IGNORE INTO ${table}(name) VALUES(?)`).run(name); audit(user.id,table,null,'added',{name}); return json(res,201,{name}); }
  if (route === '/orders/lookup' && method === 'GET') { allow(user,'admin','frontdesk'); const serial=required(url.searchParams.get('serial'),'完整串码'); const found=db.prepare('SELECT o.model,i.plan FROM orders o JOIN items i ON i.order_id=o.id WHERE o.serial=? ORDER BY o.id DESC,i.id DESC LIMIT 1').get(serial); return json(res,200,{match:found||null}); }
  if (route === '/orders' && method === 'POST') { allow(user,'admin','frontdesk'); const b=await body(req), serial=required(b.serial,'完整串码'), model=required(b.model,'型号'), customer=required(b.customer,'客户'); if(serial.length<6) bad(400,'串码至少 6 位'); const id=tx(()=>{ const ts=now(); const orderId=Number(db.prepare('INSERT INTO orders(serial,serial_last6,model,customer,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(serial,serial.slice(-6),model,customer,user.id,ts,ts).lastInsertRowid); db.prepare('INSERT OR IGNORE INTO models(name) VALUES(?)').run(model); addItem(orderId,b,user.id); audit(user.id,'order',orderId,'created',{serial,model,customer}); return orderId; }); return json(res,201,{order:getOrder(id)}); }
  if (route === '/orders' && method === 'GET') { const q=(url.searchParams.get('q')||'').trim(), status=url.searchParams.get('status')||'', rows=db.prepare(`SELECT o.*,COUNT(i.id) AS item_count,SUM(CASE WHEN i.status='completed' THEN 1 ELSE 0 END) AS completed_count FROM orders o JOIN items i ON i.order_id=o.id WHERE (?='' OR o.serial LIKE ? OR o.serial_last6 LIKE ? OR o.model LIKE ?) AND (?='' OR o.status=?) AND (?=0 OR i.technician_id=?) GROUP BY o.id ORDER BY o.id DESC`).all(q,`%${q}%`,`%${q}%`,`%${q}%`,status,status,user.role==='technician'?user.id:0,user.id); return json(res,200,{orders:rows}); }
  match=route.match(/^\/orders\/(\d+)$/);
  if(match && method==='GET') return json(res,200,{order:visibleOrder(user,Number(match[1]))});
  match=route.match(/^\/orders\/(\d+)\/items$/);
  if(match && method==='POST') { allow(user,'admin','frontdesk'); const b=await body(req), orderId=Number(match[1]); const itemId=tx(()=>{ const order=getOrder(orderId); if(order.status!=='active') bad(409,'订单已退机或取消'); const id=addItem(orderId,b,user.id); db.prepare('UPDATE orders SET updated_at=? WHERE id=?').run(now(),orderId); return id; }); return json(res,201,{item_id:itemId,order:getOrder(orderId)}); }
  match=route.match(/^\/items\/(\d+)\/assign$/);
  if(match && method==='POST') { allow(user,'admin','frontdesk'); const b=await body(req), t=technician(b.technician_id), id=Number(match[1]); const item=db.prepare('SELECT i.*,o.status AS order_status FROM items i JOIN orders o ON o.id=i.order_id WHERE i.id=?').get(id); if(!item) bad(404,'维修项目不存在'); if(item.status!=='pending'||item.order_status!=='active') bad(409,'只能转派未完成的项目'); db.prepare('UPDATE items SET technician_id=? WHERE id=?').run(t.id,id); audit(user.id,'item',id,'reassigned',{from:item.technician_id,to:t.id}); return json(res,200,{order:getOrder(item.order_id)}); }
  match=route.match(/^\/items\/(\d+)\/price$/);
  if(match && method==='PATCH') { allow(user,'admin','frontdesk'); const b=await body(req), id=Number(match[1]); const item=db.prepare('SELECT i.*,o.status AS order_status FROM items i JOIN orders o ON o.id=i.order_id WHERE i.id=?').get(id); if(!item) bad(404,'维修项目不存在'); if(item.status!=='pending'||item.order_status!=='active') bad(409,'只能修改未完成项目'); const charge=money(b.charge,'收费'), wage=money(b.wage,'工价'); db.prepare('UPDATE items SET charge_cents=?,wage_cents=? WHERE id=?').run(charge,wage,id); audit(user.id,'item',id,'price_changed',{old_charge_cents:item.charge_cents,old_wage_cents:item.wage_cents,charge_cents:charge,wage_cents:wage}); return json(res,200,{order:getOrder(item.order_id)}); }
  match=route.match(/^\/items\/(\d+)\/complete$/);
  if(match && method==='POST') { allow(user,'technician'); const id=Number(match[1]); const result=tx(()=>{ const item=db.prepare('SELECT i.*,o.status AS order_status FROM items i JOIN orders o ON o.id=i.order_id WHERE i.id=?').get(id); if(!item) bad(404,'维修项目不存在'); if(item.technician_id!==user.id) bad(403,'项目未分配给你'); if(item.status==='completed') return {already_completed:true,order:getOrder(item.order_id)}; if(item.status!=='pending'||item.order_status!=='active') bad(409,'项目不可完成'); const ts=now(); db.prepare("UPDATE items SET status='completed',completed_at=?,charge_snapshot_cents=charge_cents,wage_snapshot_cents=wage_cents,completed_by=? WHERE id=? AND status='pending'").run(ts,user.id,id); db.prepare("INSERT INTO ledger(item_id,kind,amount_cents,technician_id,created_at) VALUES(?,'charge',?,?,?)").run(id,item.charge_cents,user.id,ts); db.prepare("INSERT INTO ledger(item_id,kind,amount_cents,technician_id,created_at) VALUES(?,'wage',?,?,?)").run(id,item.wage_cents,user.id,ts); db.prepare('UPDATE orders SET updated_at=? WHERE id=?').run(ts,item.order_id); audit(user.id,'item',id,'completed',{charge_cents:item.charge_cents,wage_cents:item.wage_cents}); return {already_completed:false,order:getOrder(item.order_id)}; }); return json(res,200,result); }
  match=route.match(/^\/orders\/(\d+)\/(return|cancel)$/);
  if(match && method==='POST') { allow(user,'admin','frontdesk'); const id=Number(match[1]), target=match[2]==='return'?'returned':'cancelled'; const order=tx(()=>{ const o=getOrder(id); if(o.status!== 'active') bad(409,'订单已关闭'); const ts=now(); for(const i of o.items){ if(i.status==='completed'){ db.prepare("INSERT INTO ledger(item_id,kind,amount_cents,technician_id,created_at) VALUES(?,'charge_reversal',?,?,?)").run(i.id,-i.charge_snapshot_cents,i.technician_id,ts); db.prepare("INSERT INTO ledger(item_id,kind,amount_cents,technician_id,created_at) VALUES(?,'wage_reversal',?,?,?)").run(i.id,-i.wage_snapshot_cents,i.technician_id,ts); } db.prepare('UPDATE items SET status=? WHERE id=?').run(target,i.id); } db.prepare('UPDATE orders SET status=?,updated_at=? WHERE id=?').run(target,ts,id); audit(user.id,'order',id,target,{items:o.items.length}); return getOrder(id); }); return json(res,200,{order}); }
  if(route==='/finance' && method==='GET') { allow(user,'admin'); const from=url.searchParams.get('from')||'0000-01-01', to=url.searchParams.get('to')||'9999-12-31', tech=Number(url.searchParams.get('technician_id')||0), serial=url.searchParams.get('serial')||''; const entries=db.prepare(`SELECT l.*,i.plan,o.serial,o.model,u.username AS technician_name FROM ledger l JOIN items i ON i.id=l.item_id JOIN orders o ON o.id=i.order_id LEFT JOIN users u ON u.id=l.technician_id WHERE date(l.created_at,'+8 hours')>=? AND date(l.created_at,'+8 hours')<=? AND (?=0 OR l.technician_id=?) AND (?='' OR o.serial LIKE ?) ORDER BY l.id DESC`).all(from,to,tech,tech,serial,`%${serial}%`); const charge=entries.filter(e=>e.kind.startsWith('charge')).reduce((s,e)=>s+e.amount_cents,0), wage=entries.filter(e=>e.kind.startsWith('wage')).reduce((s,e)=>s+e.amount_cents,0); return json(res,200,{charge_cents:charge,wage_cents:wage,net_cents:charge-wage,entries}); }
  if(route==='/stats' && method==='GET') { allow(user,'technician'); const rows=db.prepare(`SELECT i.id,i.status,i.completed_at,l.amount_cents,l.created_at FROM items i LEFT JOIN ledger l ON l.item_id=i.id AND l.kind IN ('wage','wage_reversal') WHERE i.technician_id=?`).all(user.id); const today=localDay(), month=today.slice(0,7), dayOf=s=>s?new Date(new Date(s).getTime()+8*3600000).toISOString().slice(0,10):''; const summarize=(prefix)=>({wage_cents:rows.filter(r=>dayOf(r.created_at).startsWith(prefix)).reduce((s,r)=>s+(r.amount_cents||0),0),count:new Set(rows.filter(r=>r.status==='completed'&&dayOf(r.completed_at).startsWith(prefix)).map(r=>r.id)).size}); return json(res,200,{today:summarize(today),month:summarize(month),total:summarize('')}); }
  if(route==='/audit' && method==='GET') { allow(user,'admin'); const entries=db.prepare('SELECT a.*,u.username AS actor_name,u.display_name AS actor_display_name,u.role,u.is_superadmin FROM audit a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.id DESC').all().map(row=>({...row,message:operationMessage(row)})); return json(res,200,{entries}); }
  bad(404,'接口不存在');
}
function backup() { const dir=path.join(DATA_DIR,'backups'); fs.mkdirSync(dir,{recursive:true}); const file=path.join(dir,`repair-${localDay()}.sqlite`); if(!fs.existsSync(file)) { try { db.prepare('VACUUM INTO ?').run(file); } catch(e) { console.error('备份失败:',e); if(fs.existsSync(file)) fs.rmSync(file,{force:true}); } } }
backup(); setInterval(backup,60*60*1000).unref();
const server=http.createServer(async(req,res)=>{ try { const url=new URL(req.url,'http://localhost'); if(url.pathname.startsWith('/api/')||url.pathname.startsWith('/repair-api/')) await api(req,res,url); else if(req.method==='GET') serveStatic(req,res,url); else bad(404,'不存在'); } catch(e){ if(e.status) json(res,e.status,{error:e.message}); else { console.error(e); json(res,500,{error:'服务器错误'}); } } });
if(require.main===module) server.listen(PORT,HOST,()=>console.log(`管理后台: http://${HOST}:${PORT}/shouji`));
module.exports={server,db};
